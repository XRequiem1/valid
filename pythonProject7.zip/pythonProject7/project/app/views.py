from django.contrib import admin
from django.http import HttpResponse
from .models import Person
from .forms import UserForm, UserForm2
from django.shortcuts import redirect, render

def getData(request):
    tom = Person.objects.create(name='Tom', age=25, photo=bbv.jpg)

    people = Person.objects.all()
    return render(request, 'app/data.html', context={'data': people})

def index(request):
    if request.method == "POST":
        form = UserForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            age = form.cleaned_data['age']
            return HttpResponse(f'name: {name}')
        else:
            return HttpResponse('Данные не валидны')


        name = request.POST.get('name')
        return HttpResponse(f'name: {name}')
    else:

        form = UserForm()
        form2 = UserForm()
        return render(request, 'app/index.html', context={'form': form, 'form2': form2})










