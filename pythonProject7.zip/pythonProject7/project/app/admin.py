from django.contrib import admin
from django.http import HttpResponse
from .models import Person
from .forms import UserForm, UserForm2
from django.shortcuts import redirect, render

# Register your models here.






